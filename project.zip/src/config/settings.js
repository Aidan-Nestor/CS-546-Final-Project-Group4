export const settings = {
  sessionName: "nw_session",
  sessionMaxAgeMs: 1000 * 60 * 60 * 6 // 6 hours
};
